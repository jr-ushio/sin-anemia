<?php


require SYS_PATH."App.php";
require SYS_PATH."Router.php";
require APP_PATH."http/routes.php";
require SYS_PATH."Response.php";
require SYS_PATH."DB.php";
require SYS_PATH."Model.php";
require APP_PATH."models/User.php";
