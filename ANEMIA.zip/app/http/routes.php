<?php

  Router::add("/","mainController","index");
  Router::add("about","mainController","about");
